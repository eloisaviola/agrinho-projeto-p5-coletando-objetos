let personagem;
let itensCampo = [];
let itensCidade = [];
let itemsCollected = 0;
let fase = 1; // Fase inicial
let tempoRestante = 90; // Tempo para completar o nível (em segundos)
let timer;
let inimigos = [];
let velocidadeInimigos = 1.5; // Velocidade inicial dos inimigos
let gameStarted = false; // Flag para verificar se o jogo começou
let pontos = 0; // Pontuação do jogador
let maxPontos = 10; // Pontos necessários para avançar de fase
let totalInimigos = 5; // Total de inimigos por fase
let totalItens = 10; // Itens por fase
let dificuldadeAumentada = false; // Controla aumento de dificuldade

function setup() {
  createCanvas(800, 600);
  // Iniciar o timer
  timer = millis();
  personagem = new Personagem(width / 2, height - 30);
}

function draw() {
  if (!gameStarted) {
    // Tela inicial explicativa
    displayStartScreen();
    return;
  }

  // Cenário de fazenda e cidade
  background(135, 206, 235); // Céu azul
  
  // Desenhar nuvens
  drawClouds();

  // Desenhar o cenário da fazenda
  drawFarm();

  // Atualizar o timer
  if (millis() - timer >= 1000) {
    tempoRestante--;
    timer = millis();
  }

  // Verificar se o tempo acabou
  if (tempoRestante <= 0) {
    festa = true;
    displayFesta();
    return;
  }

  // Desenhar o personagem e movimentar
  personagem.move();
  personagem.display();

  // Desenhar os itens e verificar a coleta
  for (let i = itensCampo.length - 1; i >= 0; i--) {
    itensCampo[i].display();
    if (personagem.collect(itensCampo[i])) {
      itensCampo.splice(i, 1);
      itemsCollected++;
      pontos += 10; // Adiciona pontos ao coletar itens
    }
  }

  for (let i = itensCidade.length - 1; i >= 0; i--) {
    itensCidade[i].display();
    if (personagem.collect(itensCidade[i])) {
      itensCidade.splice(i, 1);
      itemsCollected++;
      pontos += 10; // Adiciona pontos ao coletar itens
    }
  }

  // Desenhar os inimigos e checar colisão
  for (let i = 0; i < inimigos.length; i++) {
    inimigos[i].move(personagem.x, personagem.y); // Perseguir o personagem
    inimigos[i].display();
    
    if (personagem.collide(inimigos[i])) {
      festa = true;
      textSize(32);
      fill(255, 0, 0);
      textAlign(CENTER, CENTER);
      text("Você foi pego pelo inimigo! Game Over!", width / 2, height / 2);
      noLoop();
    }
  }

  // Exibir o tempo restante
  fill(0);
  textSize(18);
  text("Tempo restante: " + tempoRestante + "s", 20, 30);
  text("Itens coletados: " + itemsCollected, 20, 60);
  text("Pontos: " + pontos, width - 150, 30);

  // Iniciar a festa quando o jogador coletou todos os itens
  if (itemsCollected >= totalItens) {
    faseUp();
  }

  // Se o jogador atingiu os pontos necessários, aumenta a fase
  if (pontos >= maxPontos) {
    faseUp();
  }
}

// Função para mudar de fase
function faseUp() {
  fase++; // Aumenta a fase
  itemsCollected = 0; // Zera os pontos
  tempoRestante = 90; // Reseta o tempo
  pontos = 0; // Reseta a pontuação

  // Se já atingiu a última fase, exibe a festa
  if (fase > 3) {
    festa = true;
    displayFesta();
    return;
  }

  // Criar novos itens
  itensCampo = [];
  itensCidade = [];
  criarItens();

  // Criar inimigos dependendo da fase
  inimigos = [];
  for (let i = 0; i < fase; i++) {
    inimigos.push(new Inimigo(random(width), random(height - 100))); // Aumenta o número de inimigos conforme a fase
  }

  // Aumenta a velocidade dos inimigos conforme a fase
  if (!dificuldadeAumentada) {
    velocidadeInimigos += 0.5;
    dificuldadeAumentada = true;
  }
}

// Função para desenhar as nuvens
function drawClouds() {
  fill(255);
  noStroke();
  ellipse(100, 100, 150, 80);
  ellipse(200, 120, 180, 90);
  ellipse(300, 90, 160, 80);
  ellipse(500, 80, 180, 90);
  ellipse(650, 100, 140, 70);
  ellipse(700, 130, 130, 70);
}

// Função para desenhar o cenário de fazenda
function drawFarm() {
  // Desenhar o chão
  fill(34, 139, 34); // Cor do campo (verde)
  rect(0, height - 100, width, 100);

  // Desenhar árvores (representação simples)
  fill(139, 69, 19); // Cor do tronco da árvore
  rect(50, height - 180, 30, 80);
  fill(0, 128, 0); // Cor da copa da árvore
  ellipse(65, height - 200, 80, 80);
  
  fill(139, 69, 19);
  rect(700, height - 180, 30, 80);
  fill(0, 128, 0);
  ellipse(715, height - 200, 80, 80);
  
  // Desenhar a cerca
  drawFence();
}

// Função para desenhar a cerca
function drawFence() {
  fill(139, 69, 19); // Cor do tronco da cerca (marrom)
  stroke(139, 69, 19); // Cor dos postes da cerca (marrom)

  // Postes verticais
  for (let i = 0; i < width; i += 100) {
    rect(i, height - 200, 10, 100); // Poste
  }

  // Tábuas horizontais
  stroke(139, 69, 19); // Cor das tábuas horizontais (marrom)
  for (let i = height - 150; i > height - 200; i -= 20) {
    for (let x = 0; x < width; x += 100) {
      line(x, i, x + 90, i); // Linha representando a tábua
    }
  }
}

// Função para criar os itens
function criarItens() {
  for (let i = 0; i < 5; i++) { // 5 itens do campo
    itensCampo.push(new Item(random(50, 750), random(50, 200), "campo"));
  }

  for (let i = 0; i < 5; i++) { // 5 itens da cidade
    itensCidade.push(new Item(random(50, 750), random(200, 550), "cidade"));
  }
}

// Função para exibir a tela inicial
function displayStartScreen() {
  background(180, 255, 180); // Fundo de campo

  // Desenhar elementos relacionados à fazenda
  fill(139, 69, 19);
  rect(50, height - 150, 30, 80); // Trunk da árvore
  fill(0, 128, 0);
  ellipse(65, height - 170, 80, 80); // Copa da árvore
  
  fill(255, 0, 0);
  rect(700, height - 150, 30, 80); // Outra árvore na cidade
  fill(0, 0, 255);
  ellipse(715, height - 170, 80, 80); // Copa da árvore

  // Desenhar céu e prédios
  fill(135, 206, 235); // Céu azul
  rect(550, 200, 100, 200); // Prédio na cidade

  fill(255, 255, 255); // Nuvem branca
  ellipse(300, 100, 150, 80);

  fill(0);
  textSize(32);
  textAlign(CENTER, CENTER);
  text("Bem-vindo à Fazenda e Cidade!", width / 2, height / 2 - 150);
  textSize(18);
  text("Use as setas para mover o personagem", width / 2, height / 2 - 100);
  text("Colete os itens e evite os inimigos", width / 2, height / 2 - 60);
  text("Pressione a tecla ESPAÇO para começar", width / 2, height / 2 + 40);
}

function keyPressed() {
  if (key === ' ' && !gameStarted) {
    gameStarted = true;
    faseUp();
  }
}

// Classe Personagem
class Personagem {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.size = 50;
  }

  display() {
    textSize(this.size);
    textAlign(CENTER, CENTER);
    text("🧑‍🌾", this.x, this.y); // Emoji do personagem
  }

  move() {
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= 5;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      this.x += 5;
    }
    if (keyIsDown(UP_ARROW)) {
      this.y -= 5;
    }
    if (keyIsDown(DOWN_ARROW)) {
      this.y += 5;
    }

    // Impedir que o personagem saia da tela
    this.x = constrain(this.x, 0, width);
    this.y = constrain(this.y, 0, height - 100);
  }

  collect(item) {
    let d = dist(this.x, this.y, item.x, item.y);
    return d < this.size / 2 + item.size / 2;
  }

  collide(inimigo) {
    let d = dist(this.x, this.y, inimigo.x, inimigo.y);
    return d < this.size / 2 + inimigo.size / 2;
  }
}

// Classe Item
class Item {
  constructor(x, y, tipo) {
    this.x = x;
    this.y = y;
    this.size = 20;
    this.tipo = tipo;
  }

  display() {
    textSize(this.size);
    if (this.tipo === "campo") {
      text("🌾", this.x, this.y); // Emoji de item do campo
    } else {
      text("🏙️", this.x, this.y); // Emoji de item da cidade
    }
  }
}

// Classe Inimigo
class Inimigo {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.size = 40;
  }

  display() {
    textSize(this.size);
    text("👹", this.x, this.y); // Emoji do inimigo (monstro)
  }

  move(px, py) {
    let angle = atan2(py - this.y, px - this.x);
    this.x += cos(angle) * velocidadeInimigos;
    this.y += sin(angle) * velocidadeInimigos;

    // Impedir que o inimigo saia da tela
    this.x = constrain(this.x, 0, width);
    this.y = constrain(this.y, 0, height - 100);
  }
}

// Função para exibir a festa
function displayFesta() {
  background(0, 255, 0); // Cor de fundo festiva (verde brilhante)

  fill(255, 223, 0);
  textSize(32);
  textAlign(CENTER, CENTER);
  text("Festa na Fazenda!", width / 2, height / 2);
  textSize(18);
  text("Você venceu e trouxe alegria ao campo!", width / 2, height / 2 + 40);

  // Efeitos de animação de partículas
  for (let i = 0; i < 50; i++) {
    fill(random(255), random(255), random(255), 150);
    ellipse(random(width), random(height), 10, 10);
  }
}
